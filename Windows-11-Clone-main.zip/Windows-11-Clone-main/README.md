# Windows 11 Clone
Windows 11 clone using `HTML`, `CSS`, and `Javascript`. Feel free to use any of the code anywhere you want.

This was originally motivated by one of our favorite YouTubers, `CodeWithHarry`. He made a video on this clone but he used screenshots. At the end of the video, he asked to take it to next level and do it using only `CSS`. So, that's what I did.

Although I am not on the path to be Web Developer, but I love creating beatuful UIs. In fact, at the time of creating this, I actually was on that path.

You are free to use the code in this project anywhere you like. I do own it but it's code and we are programmers. Code doesn't really belong to just one of us :D. Seriously though, use the code as you wish. Just give some sort of credit in the corner. I'll do appreciate that. xD

# Preview
All of the assets are in `svg` format. The searching also works. Each button is also clickable.

## Official Wallpaper
<img width="1680" alt="Windows 11 clone by CodeMite @najmiter" src="https://user-images.githubusercontent.com/85332859/233588697-bc365e7b-d736-4f6b-a7a8-e5268b359c3b.png">

## XP Wallpaper
<img width="1680" alt="Windows 11 clone by CodeMite @najmiter" src="https://user-images.githubusercontent.com/85332859/233588784-5ff4b577-10f1-4fa8-8a60-09d4abad3359.png">
